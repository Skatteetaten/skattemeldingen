
# ID-porten klient

Dette er en enkel klient som viser integrasjon med ID-porten og kall til et API hos skatteetaten. Konkret gjør klienten følgende:
1. Starter en system browser som sender bruker til ID-porten. 
2. Det settes også opp en enkel webserver som venter på callback fra browseren (etter vellykket pålogging i ID-porten sendes brukes til denne webserveren)
3. Etter velykket pålogging i ID-porten gjøres det et REST-kall til et API hos skatteetaten (skattemelding-API). Kallet til APIer inneholder tokenet fra punkt 2.
4. Skattemelding-APIet verifiserer tokenet og retunerer en tekststreng tilbake.

## Relevante lenker

- Klienten bruker test-miløjet i difi, "verifikasjon 2": https://samarbeid.difi.no/node/232
- OIDC-integrasjonen er beskrevet her: https://difi.github.io/felleslosninger/oidc_index.html
Man lager en klient i selvregistreringen: https://minside-samarbeid.difi.no/organization-home/services/service-admin#/

# Lokal testing
Installer følgende:
- [Python] versjon 3.7 eller nyere (https://www.python.org/downloads/). 
- [PIP](https://en.wikipedia.org/wiki/Pip_(package_manager))
- Innstaller nøvdendig bibliotek ved å kjøre: ```python3 -m pip install -r requirements.txt ```

Kjør testklienten:
- ```python3 hent.py``` (kaller ping og henter skattemedling)
- ```python3 valider.py``` (validerer skattemelding)
- Logg inn i ID-porten ved å benytte følgende testbruker: ```fødselsnr=02095301714, passord=password01, pinkode=12345```.
- Etter vellykket pålogging vil klineten gjøre kall til Skatteetatens Skattemelding-API og avslutte.

Eksempel installasjon på Ubuntu 18.04:

```sh
cd
sudo apt-get install curl build-essential libssl-dev libffi-dev python3-dev
sudo apt-get  install libssl-dev zlib1g-dev libncurses5-dev libncursesw5-dev libreadline-dev libsqlite3-dev libgdbm-dev libdb5.3-dev libbz2-dev libexpat1-dev liblzma-dev libffi-dev uuid-dev
wget https://www.python.org/ftp/python/3.8.1/Python-3.8.1.tgz
tar zxvpf Python-3.8.1.tgz 
cd Python-3.8.1/
./configure --prefix=$HOME/py381
make -j4
make install
cd
curl --location -o virtualenv-16.7.9.tar.gz https://github.com/pypa/virtualenv/tarball/16.7.9
tar zxvpf virtualenv-16.7.9.tar.gz 
( cd pypa-virtualenv-34c62ba && ~/py381/bin/python3 setup.py install)
~/py381/bin/virtualenv ve381 -p ~/py381/bin/python3  
. ~/ve381/bin/activate
python -V  # skal si Python 3.8.1
cd hent-skattemelding/
pip install -r requirements.txt 
./hent.py 
```
